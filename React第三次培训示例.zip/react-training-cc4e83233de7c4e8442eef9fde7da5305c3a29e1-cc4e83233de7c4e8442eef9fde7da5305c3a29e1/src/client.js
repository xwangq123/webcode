import React from 'react';
import ReactDOM from 'react-dom';
import TodoModel from './todo-model';

import TodoApp from './TodoApp';

const model = new TodoModel('react-todos');

const render = () => ReactDOM.render(<TodoApp model={model}/>, document.getElementById('todoApp'));

model.subscribe(render);
render();
