webpackJsonp([0],{

/***/ 0:
/*!***********************!*\
  !*** ./src/client.js ***!
  \***********************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _reactDom = __webpack_require__(/*! react-dom */ 32);
	
	var _reactDom2 = _interopRequireDefault(_reactDom);
	
	var _todoModel = __webpack_require__(/*! ./todo-model */ 178);
	
	var _todoModel2 = _interopRequireDefault(_todoModel);
	
	var _TodoApp = __webpack_require__(/*! ./TodoApp */ 180);
	
	var _TodoApp2 = _interopRequireDefault(_TodoApp);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var model = new _todoModel2.default('react-todos');
	
	var render = function render() {
	  return _reactDom2.default.render(_react2.default.createElement(_TodoApp2.default, { model: model }), document.getElementById('todoApp'));
	};
	
	model.subscribe(render);
	render();

/***/ },

/***/ 178:
/*!***************************!*\
  !*** ./src/todo-model.js ***!
  \***************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	var utils = __webpack_require__(/*! ./utils */ 179);
	
	var TodoModel = function TodoModel(key) {
	    this.key = key;
	    this.todos = utils.store(key);
	    this.onChanges = [];
	};
	
	TodoModel.prototype.subscribe = function (onChange) {
	    this.onChanges.push(onChange);
	};
	
	TodoModel.prototype.inform = function () {
	    utils.store(this.key, this.todos);
	    this.onChanges.forEach(function (cb) {
	        return cb();
	    });
	};
	
	TodoModel.prototype.addTodo = function (title) {
	    this.todos = this.todos.concat({
	        id: utils.uuid(),
	        title: title,
	        completed: false
	    });
	    this.inform();
	};
	
	TodoModel.prototype.toggleAll = function (checked) {
	    // Note: it's usually better to use immutable data structures since they're
	    // easier to reason about and React works very well with them. That's why
	    // we use map() and filter() everywhere instead of mutating the array or todo
	    // items themselves.
	    this.todos = this.todos.map(function (todo) {
	        return utils.extend({}, todo, { completed: checked });
	    });
	    this.inform();
	};
	
	TodoModel.prototype.toggle = function (todoToToggle) {
	    this.todos = this.todos.map(function (todo) {
	        return todo !== todoToToggle ? todo : utils.extend({}, todo, { completed: !todo.completed });
	    });
	    this.inform();
	};
	
	TodoModel.prototype.destroy = function (todo) {
	    this.todos = this.todos.filter(function (candidate) {
	        return candidate !== todo;
	    });
	    this.inform();
	};
	
	TodoModel.prototype.save = function (todoToSave, text) {
	    this.todos = this.todos.map(function (todo) {
	        return todo !== todoToSave ? todo : utils.extend({}, todo, { title: text });
	    });
	    this.inform();
	};
	
	TodoModel.prototype.clearCompleted = function () {
	    this.todos = this.todos.filter(function (todo) {
	        return !todo.completed;
	    });
	    this.inform();
	};
	
	module.exports = TodoModel;

/***/ },

/***/ 179:
/*!**********************!*\
  !*** ./src/utils.js ***!
  \**********************/
/***/ function(module, exports) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.uuid = uuid;
	exports.pluralize = pluralize;
	exports.store = store;
	exports.extend = extend;
	function uuid() {
	    var i = void 0,
	        random = void 0;
	    var uuid = '';
	    for (i = 0; i < 32; i++) {
	        random = Math.random() * 16 | 0;
	        if (i === 8 || i === 12 || i === 16 || i === 20) uuid += '-';
	        uuid += (i === 12 ? 4 : i === 16 ? random & 3 | 8 : random).toString(16);
	    }
	    return uuid;
	}
	
	function pluralize(count, word) {
	    return count === 1 ? word : word + 's';
	}
	
	function store(namespace, data) {
	    if (data) return localStorage.setItem(namespace, JSON.stringify(data));
	
	    var store = localStorage.getItem(namespace);
	    return store && JSON.parse(store) || [];
	}
	
	function extend() {
	    var newObj = {};
	    for (var i = 0; i < arguments.length; i++) {
	        var obj = arguments[i];
	        for (var key in obj) {
	            if (obj.hasOwnProperty(key)) newObj[key] = obj[key];
	        }
	    }
	    return newObj;
	}

/***/ },

/***/ 180:
/*!*************************!*\
  !*** ./src/TodoApp.jsx ***!
  \*************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	
	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
	
	var _director = __webpack_require__(/*! director */ 181);
	
	var _director2 = _interopRequireDefault(_director);
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _constants = __webpack_require__(/*! ./constants */ 182);
	
	var _TodoFooter = __webpack_require__(/*! ./TodoFooter */ 183);
	
	var _TodoFooter2 = _interopRequireDefault(_TodoFooter);
	
	var _TodoItem = __webpack_require__(/*! ./TodoItem */ 185);
	
	var _TodoItem2 = _interopRequireDefault(_TodoItem);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
	
	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
	
	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
	
	var TodoApp = function (_Component) {
	    _inherits(TodoApp, _Component);
	
	    function TodoApp(props) {
	        _classCallCheck(this, TodoApp);
	
	        var _this = _possibleConstructorReturn(this, (TodoApp.__proto__ || Object.getPrototypeOf(TodoApp)).call(this, props));
	
	        _this.state = {
	            nowShowing: _constants.ALL_TODOS,
	            editing: null,
	            newTodo: ''
	        };
	        _this.handleChange = _this.handleChange.bind(_this);
	        _this.handleNewTodoKeyDown = _this.handleNewTodoKeyDown.bind(_this);
	        _this.toggleAll = _this.toggleAll.bind(_this);
	        _this.toggle = _this.toggle.bind(_this);
	        _this.destroy = _this.destroy.bind(_this);
	        _this.edit = _this.edit.bind(_this);
	        _this.cancel = _this.cancel.bind(_this);
	        _this.clearCompleted = _this.clearCompleted.bind(_this);
	        return _this;
	    }
	
	    _createClass(TodoApp, [{
	        key: 'componentDidMount',
	        value: function componentDidMount() {
	            var setState = this.setState;
	            var router = new _director2.default.Router({
	                '/': setState.bind(this, { nowShowing: _constants.ALL_TODOS }),
	                '/active': setState.bind(this, { nowShowing: _constants.ACTIVE_TODOS }),
	                '/completed': setState.bind(this, { nowShowing: _constants.COMPLETED_TODOS })
	            });
	            router.init('/');
	        }
	    }, {
	        key: 'handleChange',
	        value: function handleChange(event) {
	            this.setState({
	                newTodo: event.target.value
	            });
	        }
	    }, {
	        key: 'handleNewTodoKeyDown',
	        value: function handleNewTodoKeyDown(event) {
	            if (event.keyCode !== _constants.ENTER_KEY) return;
	
	            event.preventDefault();
	
	            var val = this.state.newTodo.trim();
	
	            if (val) {
	                this.props.model.addTodo(val);
	                this.setState({
	                    newTodo: ''
	                });
	            }
	        }
	    }, {
	        key: 'toggleAll',
	        value: function toggleAll(event) {
	            var checked = event.target.checked;
	            this.props.model.toggleAll(checked);
	        }
	    }, {
	        key: 'toggle',
	        value: function toggle(todoToToggle) {
	            this.props.model.toggle(todoToToggle);
	        }
	    }, {
	        key: 'destroy',
	        value: function destroy(todo) {
	            this.props.model.destroy(todo);
	        }
	    }, {
	        key: 'edit',
	        value: function edit(todo) {
	            this.setState({
	                editing: todo.id
	            });
	        }
	    }, {
	        key: 'save',
	        value: function save(todoToSave, text) {
	            this.props.model.save(todoToSave, text);
	            this.setState({
	                editing: null
	            });
	        }
	    }, {
	        key: 'cancel',
	        value: function cancel() {
	            this.setState({
	                editing: null
	            });
	        }
	    }, {
	        key: 'clearCompleted',
	        value: function clearCompleted() {
	            this.props.model.clearCompleted();
	        }
	    }, {
	        key: 'render',
	        value: function render() {
	            var _this2 = this;
	
	            var todos = this.props.model.todos;
	
	            var shownTodos = todos.filter(function (todo) {
	                switch (_this2.state.nowShowing) {
	                    case _constants.ACTIVE_TODOS:
	                        return !todo.completed;
	                    case _constants.COMPLETED_TODOS:
	                        return todo.completed;
	                    default:
	                        return true;
	                }
	            }, this);
	
	            var todoItems = shownTodos.map(function (todo) {
	                return _react2.default.createElement(_TodoItem2.default, { key: todo.id,
	                    todo: todo,
	                    onToggle: _this2.toggle.bind(_this2, todo),
	                    onDestroy: _this2.destroy.bind(_this2, todo),
	                    onEdit: _this2.edit.bind(_this2, todo),
	                    editing: _this2.state.editing === todo.id,
	                    onSave: _this2.save.bind(_this2, todo),
	                    onCancel: _this2.cancel });
	            }, this);
	
	            var activeTodoCount = todos.reduce(function (accum, todo) {
	                return todo.completed ? accum : accum + 1;
	            }, 0);
	            var completedCount = todos.length - activeTodoCount;
	
	            var footer = null;
	            if (activeTodoCount || completedCount) footer = _react2.default.createElement(_TodoFooter2.default, { count: activeTodoCount,
	                completedCount: completedCount,
	                nowShowing: this.state.nowShowing,
	                onClearCompleted: this.clearCompleted });
	
	            var main = null;
	            if (todos.length) main = _react2.default.createElement(
	                'section',
	                { className: 'main' },
	                _react2.default.createElement('input', { className: 'toggle-all',
	                    type: 'checkbox',
	                    onChange: this.toggleAll,
	                    checked: activeTodoCount === 0 }),
	                _react2.default.createElement(
	                    'ul',
	                    { className: 'todo-list' },
	                    todoItems
	                )
	            );
	
	            return _react2.default.createElement(
	                'div',
	                null,
	                _react2.default.createElement(
	                    'header',
	                    { className: 'header' },
	                    _react2.default.createElement(
	                        'h1',
	                        null,
	                        'todos'
	                    ),
	                    _react2.default.createElement('input', { className: 'new-todo',
	                        placeholder: '\u6709\u5565\u9700\u8981\u505A\u7684\u4E8B\u513F\uFF1F',
	                        value: this.state.newTodo,
	                        onKeyDown: this.handleNewTodoKeyDown,
	                        onChange: this.handleChange,
	                        autoFocus: true })
	                ),
	                main,
	                footer
	            );
	        }
	    }]);
	
	    return TodoApp;
	}(_react.Component);
	
	exports.default = TodoApp;

/***/ },

/***/ 182:
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ function(module, exports) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var ALL_TODOS = exports.ALL_TODOS = 'all';
	var ACTIVE_TODOS = exports.ACTIVE_TODOS = 'active';
	var COMPLETED_TODOS = exports.COMPLETED_TODOS = 'completed';
	var ESCAPE_KEY = exports.ESCAPE_KEY = 27;
	var ENTER_KEY = exports.ENTER_KEY = 13;

/***/ },

/***/ 183:
/*!****************************!*\
  !*** ./src/TodoFooter.jsx ***!
  \****************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	
	var _classnames = __webpack_require__(/*! classnames */ 184);
	
	var _classnames2 = _interopRequireDefault(_classnames);
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _constants = __webpack_require__(/*! ./constants */ 182);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var TodoFooter = function TodoFooter(props) {
	    var clearButton = props.completedCount > 0 ? _react2.default.createElement(
	        'button',
	        { className: 'clear-completed', onClick: props.onClearCompleted },
	        '\u6E05\u9664\u5DF2\u5B8C\u6210'
	    ) : null;
	
	    var nowShowing = props.nowShowing;
	
	    return _react2.default.createElement(
	        'footer',
	        { className: 'footer' },
	        _react2.default.createElement(
	            'span',
	            { className: 'todo-count' },
	            '\u5269\u4F59',
	            _react2.default.createElement(
	                'strong',
	                null,
	                props.count
	            ),
	            '\u9879'
	        ),
	        _react2.default.createElement(
	            'ul',
	            { className: 'filters' },
	            _react2.default.createElement(
	                'li',
	                null,
	                _react2.default.createElement(
	                    'a',
	                    { href: '#/', className: (0, _classnames2.default)({ selected: nowShowing === _constants.ALL_TODOS }) },
	                    '\u5168\u90E8'
	                )
	            ),
	            ' ',
	            _react2.default.createElement(
	                'li',
	                null,
	                _react2.default.createElement(
	                    'a',
	                    { href: '#/active', className: (0, _classnames2.default)({ selected: nowShowing === _constants.ACTIVE_TODOS }) },
	                    '\u5F85\u529E'
	                )
	            ),
	            ' ',
	            _react2.default.createElement(
	                'li',
	                null,
	                _react2.default.createElement(
	                    'a',
	                    { href: '#/completed', className: (0, _classnames2.default)({ selected: nowShowing === _constants.COMPLETED_TODOS }) },
	                    '\u5DF2\u5B8C\u6210'
	                )
	            )
	        ),
	        clearButton
	    );
	};
	
	exports.default = TodoFooter;

/***/ },

/***/ 185:
/*!**************************!*\
  !*** ./src/TodoItem.jsx ***!
  \**************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	
	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
	
	var _classnames = __webpack_require__(/*! classnames */ 184);
	
	var _classnames2 = _interopRequireDefault(_classnames);
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _reactDom = __webpack_require__(/*! react-dom */ 32);
	
	var _reactDom2 = _interopRequireDefault(_reactDom);
	
	var _constants = __webpack_require__(/*! ./constants */ 182);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
	
	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
	
	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
	
	var TodoItem = function (_PureComponent) {
	    _inherits(TodoItem, _PureComponent);
	
	    function TodoItem(props) {
	        _classCallCheck(this, TodoItem);
	
	        var _this = _possibleConstructorReturn(this, (TodoItem.__proto__ || Object.getPrototypeOf(TodoItem)).call(this, props));
	
	        _this.state = {
	            editText: _this.props.todo.title
	        };
	        _this.handleSubmit = _this.handleSubmit.bind(_this);
	        _this.handleEdit = _this.handleEdit.bind(_this);
	        _this.handleKeyDown = _this.handleKeyDown.bind(_this);
	        _this.handleChange = _this.handleChange.bind(_this);
	        return _this;
	    }
	
	    _createClass(TodoItem, [{
	        key: 'shouldComponentUpdate',
	        value: function shouldComponentUpdate(nextProps, nextState) {
	            return nextProps.todo !== this.props.todo || nextProps.editing !== this.props.editing || nextState.editText !== this.state.editText;
	        }
	    }, {
	        key: 'componentDidUpdate',
	        value: function componentDidUpdate(prevProps) {
	            if (!prevProps.editing && this.props.editing) {
	                var node = _reactDom2.default.findDOMNode(this.refs.editField);
	                node.focus();
	                node.setSelectionRange(node.value.length, node.value.length);
	            }
	        }
	    }, {
	        key: 'handleSubmit',
	        value: function handleSubmit() {
	            var val = this.state.editText.trim();
	            if (val) {
	                this.props.onSave(val);
	                this.setState({
	                    editText: val
	                });
	            } else this.props.onDestroy();
	        }
	    }, {
	        key: 'handleEdit',
	        value: function handleEdit() {
	            this.props.onEdit();
	            this.setState({
	                editText: this.props.todo.title
	            });
	        }
	    }, {
	        key: 'handleKeyDown',
	        value: function handleKeyDown(event) {
	            if (event.which === _constants.ESCAPE_KEY) {
	                this.setState({
	                    editText: this.props.todo.title
	                });
	                this.props.onCancel(event);
	            } else if (event.which === _constants.ENTER_KEY) this.handleSubmit(event);
	        }
	    }, {
	        key: 'handleChange',
	        value: function handleChange(event) {
	            if (this.props.editing) this.setState({
	                editText: event.target.value
	            });
	        }
	    }, {
	        key: 'render',
	        value: function render() {
	            return _react2.default.createElement(
	                'li',
	                { className: (0, _classnames2.default)({
	                        completed: this.props.todo.completed,
	                        editing: this.props.editing
	                    }) },
	                _react2.default.createElement(
	                    'div',
	                    { className: 'view' },
	                    _react2.default.createElement('input', { className: 'toggle',
	                        type: 'checkbox',
	                        checked: this.props.todo.completed,
	                        onChange: this.props.onToggle }),
	                    _react2.default.createElement(
	                        'label',
	                        { onDoubleClick: this.handleEdit },
	                        this.props.todo.title
	                    ),
	                    _react2.default.createElement('button', { className: 'destroy', onClick: this.props.onDestroy })
	                ),
	                _react2.default.createElement('input', { ref: 'editField',
	                    className: 'edit',
	                    value: this.state.editText,
	                    onBlur: this.handleSubmit,
	                    onChange: this.handleChange,
	                    onKeyDown: this.handleKeyDown })
	            );
	        }
	    }]);
	
	    return TodoItem;
	}(_react.PureComponent);
	
	exports.default = TodoItem;

/***/ }

});
//# sourceMappingURL=client.js.map