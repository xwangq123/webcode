webpackJsonp([0],{

/***/ 0:
/*!***********************!*\
  !*** ./src/client.js ***!
  \***********************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _reactDom = __webpack_require__(/*! react-dom */ 32);
	
	var _reactDom2 = _interopRequireDefault(_reactDom);
	
	var _redux = __webpack_require__(/*! redux */ 178);
	
	var _reactRedux = __webpack_require__(/*! react-redux */ 199);
	
	var _reduxThunk = __webpack_require__(/*! redux-thunk */ 216);
	
	var _reduxThunk2 = _interopRequireDefault(_reduxThunk);
	
	var _reducers = __webpack_require__(/*! ./reducers */ 217);
	
	var _reducers2 = _interopRequireDefault(_reducers);
	
	var _utils = __webpack_require__(/*! ./utils */ 229);
	
	var _utils2 = _interopRequireDefault(_utils);
	
	var _TodoApp = __webpack_require__(/*! ./TodoApp */ 230);
	
	var _TodoApp2 = _interopRequireDefault(_TodoApp);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	// client.js
	// 演示项目的入口，入口模块负责调用ReactDOM.render()
	
	var STORE_NAMESPACE = 'redux-todos';
	// import actions from './actions';
	
	
	var middlewares = (0, _redux.compose)((0, _redux.applyMiddleware)(_reduxThunk2.default), window.devToolsExtension ? window.devToolsExtension() : function (f) {
	    return f;
	});
	
	// 创建整个应用的redux store ，用于存储整个应用的state，并提供初始的state值
	var store = (0, _redux.createStore)(_reducers2.default, _utils2.default.store(STORE_NAMESPACE), middlewares);
	
	// 监听state的更改，并将state持久化保存。注意subscribe仅用于演示，请不要在正式开发中使用，容易导致内存泄漏
	store.subscribe(function () {
	    var state = store.getState();
	    _utils2.default.store(STORE_NAMESPACE, state);
	    // store.dispatch(actions.upload(state.get('todos').toJS()));
	});
	
	// 在DOM ID为todoApp的节点上渲染react根组件，组件必须由react-redux的Provider包装，并为Provider赋值store属性
	_reactDom2.default.render(_react2.default.createElement(
	    _reactRedux.Provider,
	    { store: store },
	    _react2.default.createElement(_TodoApp2.default, null)
	), document.getElementById('todoApp'));

/***/ },

/***/ 217:
/*!*************************!*\
  !*** ./src/reducers.js ***!
  \*************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	
	var _immutable = __webpack_require__(/*! immutable */ 218);
	
	var _immutable2 = _interopRequireDefault(_immutable);
	
	var _reduxImmutable = __webpack_require__(/*! redux-immutable */ 219);
	
	var _actions = __webpack_require__(/*! ./actions */ 225);
	
	var _constants = __webpack_require__(/*! ./constants */ 228);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	// reducer是实际对state内容进行修改的地方
	// reducer必须是纯函数（pure function），即仅从参数输入数据且从返回值返回数据，并且在多次调用时，当输入参数一样，返回值也应一样
	// 此外，state对象应该是只读的，如果要对state进行修改，则必须返回一个修改后的新对象，因此我们使用immutable库来帮助我们完成这个效果
	
	// reducers.js
	// 项目的reducer定义模块
	
	function visibility(state, action) {
	    if (state === undefined || state === null) state = _constants.ALL_TODOS;
	
	    switch (action.type) {
	        case _actions.SET_VISIBILITY:
	            return action.payload;
	    }
	
	    return state;
	}
	
	function todos(state, action) {
	    if (state === undefined || state === null) state = _immutable2.default.List.of();
	
	    switch (action.type) {
	        case _actions.ADD_TODO:
	            return state.push(_immutable2.default.Map({
	                id: action.payload.id, // 由于纯函数的要求，此处id赋值不可以直接调用utils.uuid()方法，因为会产生随机数，只能由外部生成并由action传递进来
	                title: action.payload.title,
	                completed: false
	            }));
	        case _actions.TOGGLE:
	            return state.map(function (todo) {
	                return todo.get('id') !== action.payload.id ? todo : todo.set('completed', !todo.get('completed'));
	            });
	        case _actions.TOGGLE_ALL:
	            return state.map(function (todo) {
	                return todo.set('completed', action.payload);
	            });
	        case _actions.DESTROY:
	            return state.filter(function (candidate) {
	                return candidate.get('id') !== action.payload.id;
	            });
	        case _actions.SAVE:
	            return state.map(function (todo) {
	                return todo.get('id') !== action.payload.todo.id ? todo : todo.set('title', action.payload.title);
	            });
	        case _actions.CLEAR_COMPLETED:
	            return state.filter(function (todo) {
	                return !todo.get('completed');
	            });
	        default:
	            return state;
	    }
	}
	
	// 如果reducer是一个纯对象（POJO），那么每个key代表着state对象中的对应的key，每个值代表着处理state对象中对应的值
	// 例如本模块中，visibility()函数用于处理state对象的visibility值，而todos()函数用于处理state对象中的todos值
	// combineReducers()是redux库的一个辅助函数，可以辅助组合嵌套多个reducer函数，在本项目中使用了两个reducer函数
	// 本项目因为使用了immutable库，因此redux自带的combineReducers()函数不适用，使用了redux-immutable库的同名函数替代
	exports.default = (0, _reduxImmutable.combineReducers)({
	    visibility: visibility,
	    todos: todos
	});

/***/ },

/***/ 225:
/*!************************!*\
  !*** ./src/actions.js ***!
  \************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	// actions.js
	// 项目的action定义以及构造函数模块
	
	// 定义action名称与值，通常一个action代表用户在界面的一种操作，例如“新增”、“作废”等
	// action必须是对state树进行修改的操作，不修改state树的操作不可以定义为action
	var SET_VISIBILITY = exports.SET_VISIBILITY = 'SET_VISIBILITY';
	var setVisibility = function setVisibility(visibility) {
	    return {
	        type: SET_VISIBILITY,
	        payload: visibility
	    };
	};
	
	var ADD_TODO = exports.ADD_TODO = 'ADD_TODO';
	var addTodo = function addTodo(id, title) {
	    return {
	        type: ADD_TODO,
	        payload: {
	            id: id,
	            title: title
	        }
	    };
	};
	
	var TOGGLE = exports.TOGGLE = 'TOGGLE';
	var toggle = function toggle(todo) {
	    return {
	        type: TOGGLE,
	        payload: todo
	    };
	};
	
	var TOGGLE_ALL = exports.TOGGLE_ALL = 'TOGGLE_ALL';
	var toggleAll = function toggleAll(checked) {
	    return {
	        type: TOGGLE_ALL,
	        payload: checked
	    };
	};
	
	var DESTROY = exports.DESTROY = 'DESTROY';
	var destroy = function destroy(todo) {
	    return {
	        type: DESTROY,
	        payload: todo
	    };
	};
	
	var SAVE = exports.SAVE = 'SAVE';
	var save = function save(todo, title) {
	    return {
	        type: SAVE,
	        payload: {
	            todo: todo,
	            title: title
	        }
	    };
	};
	
	var CLEAR_COMPLETED = exports.CLEAR_COMPLETED = 'CLEAR_COMPLETED';
	var clearCompleted = function clearCompleted() {
	    return {
	        type: CLEAR_COMPLETED
	    };
	};
	
	var UPLOAD_BEGIN = exports.UPLOAD_BEGIN = 'UPLOAD_BEGIN';
	var UPLOAD_SUCCESS = exports.UPLOAD_SUCCESS = 'UPLOAD_SUCCESS';
	var UPLOAD_FAIL = exports.UPLOAD_FAIL = 'UPLOAD_FAIL';
	var upload = function upload(todos) {
	    return function (dispatch) {
	        var fetch = __webpack_require__(/*! isomorphic-fetch */ 226);
	        dispatch({
	            type: UPLOAD_BEGIN
	        });
	        fetch('/', {
	            method: 'POST',
	            headers: {
	                'Content-Type': 'application/json'
	            },
	            body: JSON.stringify(todos)
	        }).then(function (result) {
	            return dispatch({
	                type: UPLOAD_SUCCESS,
	                payload: result
	            });
	        }, function (error) {
	            return dispatch({
	                type: UPLOAD_FAIL,
	                payload: error
	            });
	        });
	    };
	};
	
	exports.default = {
	    setVisibility: setVisibility,
	    addTodo: addTodo,
	    toggle: toggle,
	    toggleAll: toggleAll,
	    destroy: destroy,
	    save: save,
	    clearCompleted: clearCompleted,
	    upload: upload
	};

/***/ },

/***/ 228:
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ function(module, exports) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	// constants.js
	// 常量定义模块
	
	var ALL_TODOS = exports.ALL_TODOS = 'all';
	var ACTIVE_TODOS = exports.ACTIVE_TODOS = 'active';
	var COMPLETED_TODOS = exports.COMPLETED_TODOS = 'completed';
	var ESCAPE_KEY = exports.ESCAPE_KEY = 27;
	var ENTER_KEY = exports.ENTER_KEY = 13;

/***/ },

/***/ 229:
/*!**********************!*\
  !*** ./src/utils.js ***!
  \**********************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.uuid = uuid;
	exports.store = store;
	
	var _immutable = __webpack_require__(/*! immutable */ 218);
	
	var _immutable2 = _interopRequireDefault(_immutable);
	
	var _constants = __webpack_require__(/*! ./constants */ 228);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	// 提供一个简便的uuid算法，注意该方法中使用了Math.random()，所以不可以在reducer中调用
	// utils,js
	// 工具模块
	
	function uuid() {
	    var i = void 0,
	        random = void 0;
	    var uuid = '';
	    for (i = 0; i < 32; i++) {
	        random = Math.random() * 16 | 0;
	        if (i === 8 || i === 12 || i === 16 || i === 20) uuid += '-';
	        uuid += (i === 12 ? 4 : i === 16 ? random & 3 | 8 : random).toString(16);
	    }
	    return uuid;
	}
	
	// 用于将state存储到HTML5 LocalStorage内的方法，如果未提供state参数，则返回一个初始state值
	function store(namespace, state) {
	    if (state) return localStorage.setItem(namespace, JSON.stringify(state.toJS()));
	
	    var store = localStorage.getItem(namespace);
	    return store ? _immutable2.default.fromJS(JSON.parse(store)) : _immutable2.default.Map();
	}
	
	exports.default = {
	    uuid: uuid,
	    store: store
	};

/***/ },

/***/ 230:
/*!*************************!*\
  !*** ./src/TodoApp.jsx ***!
  \*************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	
	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _reactRedux = __webpack_require__(/*! react-redux */ 199);
	
	var _reselect = __webpack_require__(/*! reselect */ 231);
	
	var _director = __webpack_require__(/*! director */ 232);
	
	var _director2 = _interopRequireDefault(_director);
	
	var _constants = __webpack_require__(/*! ./constants */ 228);
	
	var _actions = __webpack_require__(/*! ./actions */ 225);
	
	var _actions2 = _interopRequireDefault(_actions);
	
	var _utils = __webpack_require__(/*! ./utils */ 229);
	
	var _TodoFooter = __webpack_require__(/*! ./TodoFooter */ 233);
	
	var _TodoFooter2 = _interopRequireDefault(_TodoFooter);
	
	var _TodoItem = __webpack_require__(/*! ./TodoItem */ 235);
	
	var _TodoItem2 = _interopRequireDefault(_TodoItem);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
	
	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
	
	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // TodoApp.jsx
	// 本演示项目的根react组件
	
	var TodoApp = function (_PureComponent) {
	    _inherits(TodoApp, _PureComponent);
	
	    function TodoApp(props) {
	        _classCallCheck(this, TodoApp);
	
	        var _this = _possibleConstructorReturn(this, (TodoApp.__proto__ || Object.getPrototypeOf(TodoApp)).call(this, props));
	
	        _this.state = {
	            editing: null,
	            newTodo: ''
	        };
	        _this.handleChange = _this.handleChange.bind(_this);
	        _this.handleNewTodoKeyDown = _this.handleNewTodoKeyDown.bind(_this);
	        _this.handleToggleAll = _this.handleToggleAll.bind(_this);
	        _this.edit = _this.edit.bind(_this);
	        _this.save = _this.save.bind(_this);
	        _this.cancel = _this.cancel.bind(_this);
	        _this.clearCompleted = _this.clearCompleted.bind(_this);
	        return _this;
	    }
	
	    _createClass(TodoApp, [{
	        key: 'componentDidMount',
	        value: function componentDidMount() {
	            var props = this.props;
	            var router = new _director2.default.Router({
	                '/': function _() {
	                    return props.setVisibility(_constants.ALL_TODOS);
	                },
	                '/active': function active() {
	                    return props.setVisibility(_constants.ACTIVE_TODOS);
	                },
	                '/completed': function completed() {
	                    return props.setVisibility(_constants.COMPLETED_TODOS);
	                }
	            });
	            router.init('/');
	        }
	    }, {
	        key: 'handleChange',
	        value: function handleChange(e) {
	            this.setState({
	                newTodo: e.target.value
	            });
	        }
	    }, {
	        key: 'handleNewTodoKeyDown',
	        value: function handleNewTodoKeyDown(e) {
	            if (e.keyCode !== _constants.ENTER_KEY) return;
	
	            e.preventDefault();
	
	            var val = this.state.newTodo.trim();
	
	            if (val) {
	                this.props.addTodo((0, _utils.uuid)(), val);
	                this.setState({
	                    newTodo: ''
	                });
	            }
	        }
	    }, {
	        key: 'handleToggleAll',
	        value: function handleToggleAll(e) {
	            this.props.toggleAll(e.target.checked);
	        }
	    }, {
	        key: 'edit',
	        value: function edit(todo) {
	            this.setState({
	                editing: todo.id
	            });
	        }
	    }, {
	        key: 'save',
	        value: function save(todoToSave, text) {
	            this.props.save(todoToSave, text);
	            this.setState({
	                editing: null
	            });
	        }
	    }, {
	        key: 'cancel',
	        value: function cancel() {
	            this.setState({
	                editing: null
	            });
	        }
	    }, {
	        key: 'clearCompleted',
	        value: function clearCompleted() {
	            this.props.clearCompleted();
	        }
	    }, {
	        key: 'render',
	        value: function render() {
	            var _this2 = this;
	
	            var todos = this.props.todos;
	            var todoItems = this.props.visibleTodos.map(function (todo) {
	                return _react2.default.createElement(_TodoItem2.default, { key: todo.id,
	                    todo: todo,
	                    editing: _this2.state.editing === todo.id,
	                    onEdit: _this2.edit,
	                    onCancel: _this2.cancel,
	                    onSave: _this2.save,
	                    onToggle: _this2.props.toggle,
	                    onDestroy: _this2.props.destroy });
	            }, this);
	
	            var activeTodoCount = todos.reduce(function (accum, todo) {
	                return todo.completed ? accum : accum + 1;
	            }, 0);
	            var completedCount = todos.length - activeTodoCount;
	
	            var footer = null;
	            if (activeTodoCount || completedCount) footer = _react2.default.createElement(_TodoFooter2.default, { count: activeTodoCount,
	                completedCount: completedCount,
	                nowShowing: this.props.visibility,
	                onClearCompleted: this.clearCompleted });
	
	            var main = null;
	            if (todos.length) main = _react2.default.createElement(
	                'section',
	                { className: 'main' },
	                _react2.default.createElement('input', { className: 'toggle-all',
	                    type: 'checkbox',
	                    onChange: this.handleToggleAll,
	                    checked: activeTodoCount === 0 }),
	                _react2.default.createElement(
	                    'ul',
	                    { className: 'todo-list' },
	                    todoItems
	                )
	            );
	
	            return _react2.default.createElement(
	                'div',
	                null,
	                _react2.default.createElement(
	                    'header',
	                    { className: 'header' },
	                    _react2.default.createElement(
	                        'h1',
	                        null,
	                        'todos'
	                    ),
	                    _react2.default.createElement('input', { className: 'new-todo',
	                        placeholder: '\u6709\u5565\u9700\u8981\u505A\u7684\u4E8B\u513F\uFF1F',
	                        value: this.state.newTodo,
	                        onKeyDown: this.handleNewTodoKeyDown,
	                        onChange: this.handleChange,
	                        autoFocus: true })
	                ),
	                main,
	                footer
	            );
	        }
	    }]);
	
	    return TodoApp;
	}(_react.PureComponent);
	
	var mapStateToProps = (0, _reselect.createSelector)(function (state) {
	    return state.get('todos');
	}, function (state) {
	    return state.get('visibility');
	}, function (todos, visibility) {
	    var visibleTodos = null;
	
	    switch (visibility) {
	        case _constants.ACTIVE_TODOS:
	            visibleTodos = todos.filter(function (todo) {
	                return !todo.get('completed');
	            });
	            break;
	        case _constants.COMPLETED_TODOS:
	            visibleTodos = todos.filter(function (todo) {
	                return todo.get('completed');
	            });
	            break;
	        default:
	            visibleTodos = todos;
	            break;
	    }
	
	    return {
	        visibility: visibility,
	        todos: todos.toJS(),
	        visibleTodos: visibleTodos.toJS()
	    };
	});
	
	var mapStateToDispatch = function mapStateToDispatch(dispatch) {
	    return {
	        setVisibility: function setVisibility(visibility) {
	            return dispatch(_actions2.default.setVisibility(visibility));
	        },
	        addTodo: function addTodo(id, title) {
	            return dispatch(_actions2.default.addTodo(id, title));
	        },
	        toggle: function toggle(todo) {
	            return dispatch(_actions2.default.toggle(todo));
	        },
	        toggleAll: function toggleAll(checked) {
	            return dispatch(_actions2.default.toggleAll(checked));
	        },
	        destroy: function destroy(todo) {
	            return dispatch(_actions2.default.destroy(todo));
	        },
	        save: function save(todo, title) {
	            return dispatch(_actions2.default.save(todo, title));
	        },
	        clearCompleted: function clearCompleted() {
	            return dispatch(_actions2.default.clearCompleted());
	        }
	    };
	};
	
	exports.default = (0, _reactRedux.connect)(mapStateToProps, mapStateToDispatch)(TodoApp);

/***/ },

/***/ 233:
/*!****************************!*\
  !*** ./src/TodoFooter.jsx ***!
  \****************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	
	var _classnames = __webpack_require__(/*! classnames */ 234);
	
	var _classnames2 = _interopRequireDefault(_classnames);
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _constants = __webpack_require__(/*! ./constants */ 228);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var TodoFooter = function TodoFooter(props) {
	    var clearButton = props.completedCount > 0 ? _react2.default.createElement(
	        'button',
	        { className: 'clear-completed', onClick: props.onClearCompleted },
	        '\u6E05\u9664\u5DF2\u5B8C\u6210'
	    ) : null;
	
	    var nowShowing = props.nowShowing;
	
	    return _react2.default.createElement(
	        'footer',
	        { className: 'footer' },
	        _react2.default.createElement(
	            'span',
	            { className: 'todo-count' },
	            '\u5269\u4F59',
	            _react2.default.createElement(
	                'strong',
	                null,
	                props.count
	            ),
	            '\u9879'
	        ),
	        _react2.default.createElement(
	            'ul',
	            { className: 'filters' },
	            _react2.default.createElement(
	                'li',
	                null,
	                _react2.default.createElement(
	                    'a',
	                    { href: '#/', className: (0, _classnames2.default)({ selected: nowShowing === _constants.ALL_TODOS }) },
	                    '\u5168\u90E8'
	                )
	            ),
	            ' ',
	            _react2.default.createElement(
	                'li',
	                null,
	                _react2.default.createElement(
	                    'a',
	                    { href: '#/active', className: (0, _classnames2.default)({ selected: nowShowing === _constants.ACTIVE_TODOS }) },
	                    '\u5F85\u529E'
	                )
	            ),
	            ' ',
	            _react2.default.createElement(
	                'li',
	                null,
	                _react2.default.createElement(
	                    'a',
	                    { href: '#/completed', className: (0, _classnames2.default)({ selected: nowShowing === _constants.COMPLETED_TODOS }) },
	                    '\u5DF2\u5B8C\u6210'
	                )
	            )
	        ),
	        clearButton
	    );
	}; // TodoFooter.jsx
	// 本演示项目的react组件，用于呈现底部操作栏
	
	exports.default = TodoFooter;

/***/ },

/***/ 235:
/*!**************************!*\
  !*** ./src/TodoItem.jsx ***!
  \**************************/
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	
	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
	
	var _classnames = __webpack_require__(/*! classnames */ 234);
	
	var _classnames2 = _interopRequireDefault(_classnames);
	
	var _react = __webpack_require__(/*! react */ 1);
	
	var _react2 = _interopRequireDefault(_react);
	
	var _reactDom = __webpack_require__(/*! react-dom */ 32);
	
	var _reactDom2 = _interopRequireDefault(_reactDom);
	
	var _constants = __webpack_require__(/*! ./constants */ 228);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
	
	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
	
	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } // TodoItem.jsx
	// 本演示项目的react组件，用于TODO列表的单项呈现
	
	var TodoItem = function (_Component) {
	    _inherits(TodoItem, _Component);
	
	    function TodoItem(props) {
	        _classCallCheck(this, TodoItem);
	
	        var _this = _possibleConstructorReturn(this, (TodoItem.__proto__ || Object.getPrototypeOf(TodoItem)).call(this, props));
	
	        _this.state = {
	            editText: _this.props.todo.title
	        };
	        _this.handleTitleDoubleClick = _this.handleTitleDoubleClick.bind(_this);
	        _this.handleEditKeyDown = _this.handleEditKeyDown.bind(_this);
	        _this.handleEditChange = _this.handleEditChange.bind(_this);
	        _this.handleEditSubmit = _this.handleEditSubmit.bind(_this);
	        _this.handleToggleChange = _this.handleToggleChange.bind(_this);
	        _this.handleDestroyClick = _this.handleDestroyClick.bind(_this);
	        return _this;
	    }
	
	    _createClass(TodoItem, [{
	        key: 'shouldComponentUpdate',
	        value: function shouldComponentUpdate(nextProps, nextState) {
	            return nextProps.todo !== this.props.todo || nextProps.editing !== this.props.editing || nextState.editText !== this.state.editText;
	        }
	    }, {
	        key: 'componentDidUpdate',
	        value: function componentDidUpdate(prevProps) {
	            if (!prevProps.editing && this.props.editing) {
	                var node = _reactDom2.default.findDOMNode(this.refs.editField);
	                node.focus();
	                node.setSelectionRange(node.value.length, node.value.length);
	            }
	        }
	    }, {
	        key: 'handleTitleDoubleClick',
	        value: function handleTitleDoubleClick() {
	            this.props.onEdit(this.props.todo);
	            this.setState({
	                editText: this.props.todo.title
	            });
	        }
	    }, {
	        key: 'handleEditKeyDown',
	        value: function handleEditKeyDown(e) {
	            if (e.which === _constants.ESCAPE_KEY) {
	                this.setState({
	                    editText: this.props.todo.title
	                });
	                this.props.onCancel();
	            } else if (e.which === _constants.ENTER_KEY) this.handleEditSubmit();
	        }
	    }, {
	        key: 'handleEditChange',
	        value: function handleEditChange(e) {
	            if (this.props.editing) this.setState({
	                editText: e.target.value
	            });
	        }
	    }, {
	        key: 'handleEditSubmit',
	        value: function handleEditSubmit() {
	            var val = this.state.editText.trim();
	            if (val) {
	                this.props.onSave(this.props.todo, val);
	                this.setState({
	                    editText: val
	                });
	            } else this.props.onDestroy(this.props.todo);
	        }
	    }, {
	        key: 'handleToggleChange',
	        value: function handleToggleChange() {
	            this.props.onToggle(this.props.todo);
	        }
	    }, {
	        key: 'handleDestroyClick',
	        value: function handleDestroyClick() {
	            this.props.onDestroy(this.props.todo);
	        }
	    }, {
	        key: 'render',
	        value: function render() {
	            return _react2.default.createElement(
	                'li',
	                { className: (0, _classnames2.default)({
	                        completed: this.props.todo.completed,
	                        editing: this.props.editing
	                    }) },
	                _react2.default.createElement(
	                    'div',
	                    { className: 'view' },
	                    _react2.default.createElement('input', { className: 'toggle',
	                        type: 'checkbox',
	                        checked: this.props.todo.completed,
	                        onChange: this.handleToggleChange }),
	                    _react2.default.createElement(
	                        'label',
	                        { onDoubleClick: this.handleTitleDoubleClick },
	                        this.props.todo.title
	                    ),
	                    _react2.default.createElement('button', { className: 'destroy', onClick: this.handleDestroyClick })
	                ),
	                _react2.default.createElement('input', { ref: 'editField',
	                    className: 'edit',
	                    value: this.state.editText,
	                    onBlur: this.handleEditSubmit,
	                    onChange: this.handleEditChange,
	                    onKeyDown: this.handleEditKeyDown })
	            );
	        }
	    }]);
	
	    return TodoItem;
	}(_react.Component);
	
	exports.default = TodoItem;

/***/ }

});
//# sourceMappingURL=client.js.map