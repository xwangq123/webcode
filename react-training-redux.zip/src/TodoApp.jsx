// TodoApp.jsx
// 本演示项目的根react组件

import React, {PureComponent} from 'react';
import {connect} from 'react-redux';
import {createSelector} from 'reselect';
import director from 'director';

import {ALL_TODOS, ACTIVE_TODOS, COMPLETED_TODOS, ENTER_KEY} from './constants';
import actions from './actions';
import {uuid} from './utils';

import TodoFooter from './TodoFooter';
import TodoItem from './TodoItem';

class TodoApp extends PureComponent {
    constructor(props) {
        super(props);
        this.state = {
            editing: null,
            newTodo: ''
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleNewTodoKeyDown = this.handleNewTodoKeyDown.bind(this);
        this.handleToggleAll = this.handleToggleAll.bind(this);
        this.edit = this.edit.bind(this);
        this.save = this.save.bind(this);
        this.cancel = this.cancel.bind(this);
        this.clearCompleted = this.clearCompleted.bind(this);
    }

    componentDidMount() {
        const props = this.props;
        const router = new director.Router({
            '/': () => props.setVisibility(ALL_TODOS),
            '/active': () => props.setVisibility(ACTIVE_TODOS),
            '/completed': () => props.setVisibility(COMPLETED_TODOS)
        });
        router.init('/');
    }

    handleChange(e) {
        this.setState({
            newTodo: e.target.value
        });
    }

    handleNewTodoKeyDown(e) {
        if(e.keyCode !== ENTER_KEY)
            return;

        e.preventDefault();

        const val = this.state.newTodo.trim();

        if(val) {
            this.props.addTodo(uuid(), val);
            this.setState({
                newTodo: ''
            });
        }
    }

    handleToggleAll(e) {
        this.props.toggleAll(e.target.checked);
    }

    edit(todo) {
        this.setState({
            editing: todo.id
        });
    }

    save(todoToSave, text) {
        this.props.save(todoToSave, text);
        this.setState({
            editing: null
        });
    }

    cancel() {
        this.setState({
            editing: null
        });
    }

    clearCompleted() {
        this.props.clearCompleted();
    }

    render() {
        const todos = this.props.todos;
        const todoItems = this.props.visibleTodos.map(todo => (
            <TodoItem key={todo.id}
                      todo={todo}
                      editing={this.state.editing === todo.id}
                      onEdit={this.edit}
                      onCancel={this.cancel}
                      onSave={this.save}
                      onToggle={this.props.toggle}
                      onDestroy={this.props.destroy}/>
        ), this);

        const activeTodoCount = todos.reduce((accum, todo) => todo.completed ? accum : accum + 1, 0);
        const completedCount = todos.length - activeTodoCount;

        let footer = null;
        if(activeTodoCount || completedCount)
            footer = (
                <TodoFooter count={activeTodoCount}
                            completedCount={completedCount}
                            nowShowing={this.props.visibility}
                            onClearCompleted={this.clearCompleted}/>
            );

        let main = null;
        if(todos.length)
            main = (
                <section className="main">
                    <input className="toggle-all"
                           type="checkbox"
                           onChange={this.handleToggleAll}
                           checked={activeTodoCount === 0}/>
                    <ul className="todo-list">
                        {todoItems}
                    </ul>
                </section>
            );

        return (
            <div>
                <header className="header">
                    <h1>todos</h1>
                    <input className="new-todo"
                           placeholder="有啥需要做的事儿？"
                           value={this.state.newTodo}
                           onKeyDown={this.handleNewTodoKeyDown}
                           onChange={this.handleChange}
                           autoFocus={true}/>
                </header>
                {main}
                {footer}
            </div>
        );
    }
}

const mapStateToProps = createSelector(
    state => state.get('todos'),
    state => state.get('visibility'),
    (todos, visibility) => {
        let visibleTodos = null;

        switch(visibility) {
            case ACTIVE_TODOS:
                visibleTodos = todos.filter(todo => !todo.get('completed'));
                break;
            case COMPLETED_TODOS:
                visibleTodos = todos.filter(todo => todo.get('completed'));
                break;
            default:
                visibleTodos = todos;
                break;
        }

        return {
            visibility,
            todos: todos.toJS(),
            visibleTodos: visibleTodos.toJS()
        };
    }
);

const mapDispatchToProps = dispatch => ({
    setVisibility: visibility => dispatch(actions.setVisibility(visibility)),
    addTodo: (id, title) => dispatch(actions.addTodo(id, title)),
    toggle: todo => dispatch(actions.toggle(todo)),
    toggleAll: checked => dispatch(actions.toggleAll(checked)),
    destroy: todo => dispatch(actions.destroy(todo)),
    save: (todo, title) => dispatch(actions.save(todo, title)),
    clearCompleted: () => dispatch(actions.clearCompleted())
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoApp);
