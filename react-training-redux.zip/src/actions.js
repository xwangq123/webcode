// actions.js
// 项目的action定义以及构造函数模块

// 定义action名称与值，通常一个action代表用户在界面的一种操作，例如“新增”、“作废”等
// action必须是对state树进行修改的操作，不修改state树的操作不可以定义为action
export const SET_VISIBILITY = 'SET_VISIBILITY';
const setVisibility = visibility => ({
    type: SET_VISIBILITY,
    payload: visibility
});

export const ADD_TODO = 'ADD_TODO';
const addTodo = (id, title) => ({
    type: ADD_TODO,
    payload: {
        id,
        title
    }
});

export const TOGGLE = 'TOGGLE';
const toggle = todo => ({
    type: TOGGLE,
    payload: todo
});

export const TOGGLE_ALL = 'TOGGLE_ALL';
const toggleAll = checked => ({
    type: TOGGLE_ALL,
    payload: checked
});

export const DESTROY = 'DESTROY';
const destroy = todo => ({
    type: DESTROY,
    payload: todo
});

export const SAVE = 'SAVE';
const save = (todo, title) => ({
    type: SAVE,
    payload: {
        todo,
        title
    }
});

export const CLEAR_COMPLETED = 'CLEAR_COMPLETED';
const clearCompleted = () => ({
    type: CLEAR_COMPLETED
});

export const UPLOAD_BEGIN = 'UPLOAD_BEGIN';
export const UPLOAD_SUCCESS = 'UPLOAD_SUCCESS';
export const UPLOAD_FAIL = 'UPLOAD_FAIL';
const upload = todos => dispatch => {
    const fetch = require('isomorphic-fetch');
    dispatch({
        type: UPLOAD_BEGIN
    });
    fetch('/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(todos)
    }).then(
        result => dispatch({
            type: UPLOAD_SUCCESS,
            payload: result
        }),
        error => dispatch({
            type: UPLOAD_FAIL,
            payload: error
        })
    );
};

export default {
    setVisibility,
    addTodo,
    toggle,
    toggleAll,
    destroy,
    save,
    clearCompleted,
    upload
}
