// TodoFooter.jsx
// 本演示项目的react组件，用于呈现底部操作栏

import classNames from 'classnames';
import React from 'react';

import {ALL_TODOS, ACTIVE_TODOS, COMPLETED_TODOS} from './constants';

const TodoFooter = props => {
    const clearButton = props.completedCount > 0
        ? <button className="clear-completed" onClick={props.onClearCompleted}>清除已完成</button>
        : null;

    const nowShowing = props.nowShowing;

    return (
        <footer className="footer">
            <span className="todo-count">
                剩余<strong>{props.count}</strong>项
            </span>
            <ul className="filters">
                <li>
                    <a href="#/" className={classNames({selected: nowShowing === ALL_TODOS})}>
                        全部
                    </a>
                </li>
                {' '}
                <li>
                    <a href="#/active" className={classNames({selected: nowShowing === ACTIVE_TODOS})}>
                        待办
                    </a>
                </li>
                {' '}
                <li>
                    <a href="#/completed" className={classNames({selected: nowShowing === COMPLETED_TODOS})}>
                        已完成
                    </a>
                </li>
            </ul>
            {clearButton}
        </footer>
    );
};

export default TodoFooter;
