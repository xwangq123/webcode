// reducers.js
// 项目的reducer定义模块

import Immutable from 'immutable';
import {combineReducers} from 'redux-immutable';
import {SET_VISIBILITY, ADD_TODO, TOGGLE, TOGGLE_ALL, DESTROY, SAVE, CLEAR_COMPLETED} from './actions';
import {ALL_TODOS} from './constants';

// reducer是实际对state内容进行修改的地方
// reducer必须是纯函数（pure function），即仅从参数输入数据且从返回值返回数据，并且在多次调用时，当输入参数一样，返回值也应一样
// 此外，state对象应该是只读的，如果要对state进行修改，则必须返回一个修改后的新对象，因此我们使用immutable库来帮助我们完成这个效果

function visibility(state, action) {
    if(state === undefined || state === null)
        state = ALL_TODOS;

    switch(action.type) {
        case SET_VISIBILITY:
            return action.payload;
    }

    return state;
}

function todos(state, action) {
    if(state === undefined || state === null)
        state = Immutable.List.of();

    switch(action.type) {
        case ADD_TODO:
            return state.push(Immutable.Map({
                id: action.payload.id,  // 由于纯函数的要求，此处id赋值不可以直接调用utils.uuid()方法，因为会产生随机数，只能由外部生成并由action传递进来
                title: action.payload.title,
                completed: false
            }));
        case TOGGLE:
            return state.map(todo => todo.get('id') !== action.payload.id ? todo : todo.set('completed', !todo.get('completed')));
        case TOGGLE_ALL:
            return state.map(todo => todo.set('completed', action.payload));
        case DESTROY:
            return state.filter(candidate => candidate.get('id') !== action.payload.id);
        case SAVE:
            return state.map(todo => todo.get('id') !== action.payload.todo.id ? todo : todo.set('title', action.payload.title));
        case CLEAR_COMPLETED:
            return state.filter(todo => !todo.get('completed'));
        default:
            return state;
    }
}

// 如果reducer是一个纯对象（POJO），那么每个key代表着state对象中的对应的key，每个值代表着处理state对象中对应的值
// 例如本模块中，visibility()函数用于处理state对象的visibility值，而todos()函数用于处理state对象中的todos值
// combineReducers()是redux库的一个辅助函数，可以辅助组合嵌套多个reducer函数，在本项目中使用了两个reducer函数
// 本项目因为使用了immutable库，因此redux自带的combineReducers()函数不适用，使用了redux-immutable库的同名函数替代
export default (combineReducers({
    visibility,
    todos
}));
